#!/usr/bin/env python3
"""
Servidor da Tesouraria da tribo (relíquias e bandeiras) do Agendador TW.

Só biblioteca padrão do Python 3.8+ (http.server + sqlite3): nada para instalar.
Ver ../agendador/prompts.md (Parte 1: 1.4 a 1.7) para o modelo.

Variáveis de ambiente:
  HOST (127.0.0.1), PORT (8787), DB (tesouraria.db ao lado deste arquivo),
  ACCESS_LOG (access.log ao lado), ALLOW_ORIGIN (vazio = sem CORS: o script usa GM_xmlhttpRequest, que não precisa).
"""

import hashlib
import json
import os
import re
import secrets
import sqlite3
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

HERE = os.path.dirname(os.path.abspath(__file__))
MAX_BODY = 2 * 1024 * 1024
ACTIVE = (
    "pedido",
    "aceito",
    "preparo",
    "ida_oferta",
    "ida_ok",
    "em_uso",
    "volta_oferta",
)
FINAL = ("recusado", "cancelado", "devolvido", "quebrado")
# com a relíquia/bandeira já fora do dono (quem pegou precisa ter)
# com a relíquia/bandeira já com quem pegou. "volta_oferta" fica de fora: a relíquia pode ter acabado de sair (o dono aceitou
# a devolução e ainda não marcou "devolvido"); não é quebra
WITH_BORROWER = ("ida_ok", "em_uso")

# transições: (de, para) → quem pode ('owner' | 'borrower' | 'both')
TRANSITIONS = {
    ("pedido", "aceito"): "owner",
    ("pedido", "recusado"): "owner",
    ("pedido", "cancelado"): "both",
    ("aceito", "preparo"): "owner",
    ("aceito", "ida_oferta"): "owner",  # relíquia já livre: pula o preparo
    ("aceito", "cancelado"): "both",
    ("preparo", "ida_oferta"): "owner",
    (
        "preparo",
        "aceito",
    ): "owner",  # não deu para tirar (cooldown, lealdade): volta e reagenda
    ("preparo", "cancelado"): "both",
    ("ida_oferta", "ida_ok"): "borrower",  # aceitou a oferta no jogo
    ("ida_oferta", "aceito"): "owner",  # oferta não aceita a tempo: apagada, reagenda
    ("ida_oferta", "cancelado"): "both",
    ("ida_ok", "em_uso"): "borrower",  # equipou / atribuiu
    ("ida_ok", "volta_oferta"): "borrower",  # devolve sem ter equipado
    ("em_uso", "volta_oferta"): "borrower",
    ("volta_oferta", "devolvido"): "owner",  # aceitou a devolução no jogo
    (
        "volta_oferta",
        "em_uso",
    ): "borrower",  # oferta de volta não aceita: apagada, tenta de novo
}


def now_ms():
    return int(time.time() * 1000)


def sha(s):
    return hashlib.sha256(s.encode("utf8")).hexdigest()


class ApiError(Exception):
    def __init__(self, status, msg):
        super().__init__(msg)
        self.status = status
        self.msg = msg


class RateLimit:
    """Janela deslizante simples: no máximo `n` pedidos por `per` segundos por chave (token ou IP)."""

    def __init__(self, n, per):
        self.n, self.per, self.hits, self.lock = n, per, {}, threading.Lock()

    def ok(self, key):
        t = time.time()
        with self.lock:
            h = [x for x in self.hits.get(key, []) if t - x < self.per]
            if len(h) >= self.n:
                self.hits[key] = h
                return False
            h.append(t)
            self.hits[key] = h
            if len(self.hits) > 5000:   # limpeza: chaves paradas
                for k in [k for k, v in self.hits.items() if not v or t - v[-1] > self.per]:
                    del self.hits[k]
            return True


class Store:
    """SQLite com uma conexão protegida por trava (servidor pequeno: simplicidade > vazão)."""

    def __init__(self, path):
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        self.cond = threading.Condition(
            self.lock
        )  # avisa quem espera eventos (long-poll / SSE)
        self.online = {}
        self.last_poll = {}  # (world, player_id) → nº de conexões de eventos abertas
        with self.lock:
            self.db.executescript("""
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS tribes (world TEXT, ally_id TEXT, key_hash TEXT, created INTEGER, PRIMARY KEY (world, ally_id));
            CREATE TABLE IF NOT EXISTS members (world TEXT, ally_id TEXT, player_id TEXT, name TEXT, token_hash TEXT,
              role TEXT, created INTEGER, last_seen INTEGER, PRIMARY KEY (world, player_id));
            CREATE INDEX IF NOT EXISTS members_tok ON members(token_hash);
            CREATE TABLE IF NOT EXISTS snapshots (world TEXT, player_id TEXT, ally_id TEXT, at INTEGER, data TEXT, PRIMARY KEY (world, player_id));
            CREATE TABLE IF NOT EXISTS loans (id INTEGER PRIMARY KEY AUTOINCREMENT, world TEXT, ally_id TEXT, kind TEXT,
              owner_id TEXT, borrower_id TEXT, item TEXT, mode TEXT, collateral TEXT, target TEXT, start INTEGER, end INTEGER,
              note TEXT, state TEXT, late INTEGER DEFAULT 0, offer_id TEXT, created INTEGER, updated INTEGER);
            CREATE TABLE IF NOT EXISTS loan_events (id INTEGER PRIMARY KEY AUTOINCREMENT, loan_id INTEGER, at INTEGER,
              actor TEXT, from_state TEXT, to_state TEXT, data TEXT);
            CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY AUTOINCREMENT, world TEXT, player_id TEXT, at INTEGER, type TEXT, data TEXT);
            CREATE INDEX IF NOT EXISTS events_p ON events(world, player_id, id);
            """)
            self.db.commit()

    # ---------- utilidades ----------
    def q(self, sql, args=()):
        return self.db.execute(sql, args)

    def emit(self, world, player_ids, typ, data):
        """Evento para cada jogador (fica guardado: quem estava offline lê depois por since=)."""
        t = now_ms()
        for pid in set(str(p) for p in player_ids if p is not None):
            self.q(
                "INSERT INTO events (world, player_id, at, type, data) VALUES (?,?,?,?,?)",
                (world, pid, t, typ, json.dumps(data, ensure_ascii=False)),
            )
        self.cond.notify_all()

    def admins(self, world, ally):
        return [
            r["player_id"]
            for r in self.q(
                "SELECT player_id FROM members WHERE world=? AND ally_id=? AND role='admin'",
                (world, ally),
            )
        ]

    # ---------- membros ----------
    def register(self, b):
        world, ally, pid = (
            str(b.get("world") or ""),
            str(b.get("ally_id") or ""),
            str(b.get("player_id") or ""),
        )
        name, key = str(b.get("player_name") or "")[:64], str(b.get("tribe_key") or "")
        if (
            not re.match(r"^[a-z]{2,4}\d{1,4}[a-z]?$", world)
            or not ally.isdigit()
            or ally == "0"
            or not pid.isdigit()
        ):
            raise ApiError(
                400, "mundo, tribo ou jogador inválido (precisa estar numa tribo)"
            )
        if len(key) < 6:
            raise ApiError(400, "chave da tribo curta (mínimo 6 caracteres)")
        with self.lock:
            tribe = self.q(
                "SELECT * FROM tribes WHERE world=? AND ally_id=?", (world, ally)
            ).fetchone()
            role = None
            if not tribe:
                self.q(
                    "INSERT INTO tribes VALUES (?,?,?,?)",
                    (world, ally, sha(key), now_ms()),
                )
                role = "admin"  # 1º da tribo
            elif not secrets.compare_digest(tribe["key_hash"], sha(key)):
                raise ApiError(403, "chave da tribo errada")
            token = secrets.token_hex(24)
            old = self.q(
                "SELECT * FROM members WHERE world=? AND player_id=?", (world, pid)
            ).fetchone()
            if (
                old
                and old["ally_id"] == ally
                and old["role"] in ("admin", "member", "pending")
            ):
                role = role or old["role"]
            role = role or "pending"
            self.q(
                "INSERT OR REPLACE INTO members VALUES (?,?,?,?,?,?,?,?)",
                (
                    world,
                    ally,
                    pid,
                    name,
                    sha(token),
                    role,
                    old["created"] if old else now_ms(),
                    now_ms(),
                ),
            )
            if role == "pending":
                self.emit(
                    world,
                    self.admins(world, ally),
                    "membro_pendente",
                    {"player_id": pid, "name": name},
                )
            self.db.commit()
            return {"token": token, "role": role}

    def auth(self, token):
        if not token:
            raise ApiError(401, "sem token")
        with self.lock:
            m = self.q(
                "SELECT * FROM members WHERE token_hash=?", (sha(token),)
            ).fetchone()
            if not m:
                raise ApiError(401, "token inválido")
            self.q(
                "UPDATE members SET last_seen=? WHERE world=? AND player_id=?",
                (now_ms(), m["world"], m["player_id"]),
            )
            self.db.commit()
            return dict(m)

    @staticmethod
    def need(m, *roles):
        if m["role"] not in roles:
            raise ApiError(
                403,
                "aguardando aprovação do admin da tribo"
                if m["role"] == "pending"
                else "sem permissão",
            )

    def members(self, m):
        self.need(m, "admin", "member", "pending")
        with self.lock:
            rows = self.q(
                "SELECT player_id, name, role, created, last_seen FROM members WHERE world=? AND ally_id=? AND role!=? ORDER BY created",
                (m["world"], m["ally_id"], "removed"),
            ).fetchall()
            return [
                dict(r, online=self.is_online(m["world"], r["player_id"]))
                for r in rows
                if m["role"] == "admin"
                or r["role"] != "pending"
                or r["player_id"] == m["player_id"]
            ]

    def set_role(self, m, pid, action):
        self.need(m, "admin")
        with self.lock:
            t = self.q(
                "SELECT * FROM members WHERE world=? AND ally_id=? AND player_id=?",
                (m["world"], m["ally_id"], pid),
            ).fetchone()
            if not t:
                raise ApiError(404, "membro não encontrado")
            if action == "approve":
                role = "member"
            elif action == "admin":
                role = "admin"
            elif action == "remove":
                if (
                    pid == m["player_id"]
                    and len(self.admins(m["world"], m["ally_id"])) <= 1
                ):
                    raise ApiError(409, "você é o único admin")
                role = "removed"
                self.q(
                    "DELETE FROM snapshots WHERE world=? AND player_id=?",
                    (m["world"], pid),
                )
            else:
                raise ApiError(400, "ação desconhecida")
            self.q(
                "UPDATE members SET role=? WHERE world=? AND player_id=?",
                (role, m["world"], pid),
            )
            self.emit(m["world"], [pid], "papel", {"role": role})
            self.db.commit()
            return {"player_id": pid, "role": role}

    # ---------- fotos e estoque ----------
    def put_snapshot(self, m, b):
        self.need(m, "admin", "member")
        if str(b.get("ally_id") or "") != m["ally_id"]:
            with self.lock:  # saiu da tribo (ou mudou): tira do estoque e do cadastro
                self.q(
                    "UPDATE members SET role='removed' WHERE world=? AND player_id=?",
                    (m["world"], m["player_id"]),
                )
                self.q(
                    "DELETE FROM snapshots WHERE world=? AND player_id=?",
                    (m["world"], m["player_id"]),
                )
                open_loans = self.q(
                    "SELECT id, owner_id, borrower_id FROM loans WHERE world=? AND ally_id=? AND (owner_id=? OR borrower_id=?) AND state IN (%s)" % ",".join("?" * len(ACTIVE)),
                    (m["world"], m["ally_id"], m["player_id"], m["player_id"]) + ACTIVE,
                ).fetchall()
                others = [x["owner_id"] if x["borrower_id"] == m["player_id"] else x["borrower_id"] for x in open_loans]
                self.emit(
                    m["world"],
                    self.admins(m["world"], m["ally_id"]) + others,
                    "membro_saiu",
                    {"player_id": m["player_id"], "name": m["name"], "emprestimos": [x["id"] for x in open_loans]},
                )
                for x in open_loans:
                    self.q("INSERT INTO loan_events (loan_id, at, actor, from_state, to_state, data) VALUES (?,?,?,?,?,?)",
                           (x["id"], now_ms(), "servidor", None, None, json.dumps({"alerta": "saiu_da_tribo", "quem": m["name"]}, ensure_ascii=False)))
                self.db.commit()
            raise ApiError(409, "você não está mais nesta tribo")
        KEYS = (
                "relics",
                "relics_at",
                "offers",
                "offers_at",
                "flags",
                "flags_at",
                "flag_names",
                "flag_villages",
                "flag_villages_at",
                "effects",
                "villages",
                "server_time",
                "sitter",
                "version",
            )
        # junta com a foto anterior: o que não veio continua (o script só manda as partes pesadas quando mudam)
        with self.lock:
            old = self.q("SELECT data FROM snapshots WHERE world=? AND player_id=?", (m["world"], m["player_id"])).fetchone()
        prev = json.loads(old["data"]) if old else {}
        data = {k: (b[k] if k in b else prev.get(k)) for k in KEYS}
        # segurança: o servidor não guarda ONDE estão as relíquias (golpe em tribo): sem aldeias, sem id da aldeia
        for k in ("villages", "effects", "flag_villages", "flag_villages_at"):
            data[k] = None
        if isinstance(data.get("relics"), list):
            data["relics"] = [dict({k: v for k, v in r.items() if k != "village_id"}, equipped=bool(r.get("village_id") or r.get("equipped"))) for r in data["relics"] if isinstance(r, dict)]
        if not isinstance(data["relics"], list) and not any(data[k] for k in ("flags", "flag_villages", "effects")):
            raise ApiError(400, "foto vazia")
        with self.lock:
            self.q(
                "INSERT OR REPLACE INTO snapshots VALUES (?,?,?,?,?)",
                (
                    m["world"],
                    m["player_id"],
                    m["ally_id"],
                    now_ms(),
                    json.dumps(data, ensure_ascii=False),
                ),
            )
            broken = self.check_breaks(m, data)
            self.db.commit()
        return {"ok": True, "quebrados": broken}

    def check_breaks(self, m, data):
        """Relíquia emprestada que sumiu do inventário de quem está com ela = acordo quebrado."""
        if not isinstance(data.get("relics"), list):
            return []
        have = set(str(r.get("id")) for r in data["relics"] if isinstance(r, dict))
        out = []
        for L in self.q(
            "SELECT * FROM loans WHERE world=? AND kind='relic' AND borrower_id=? AND state IN (%s)"
            % ",".join("?" * len(WITH_BORROWER)),
            (m["world"], m["player_id"]) + WITH_BORROWER,
        ).fetchall():
            rid = str(json.loads(L["item"]).get("relic_id"))
            got = self.q("SELECT MIN(at) FROM loan_events WHERE loan_id=? AND to_state='ida_ok'", (L["id"],)).fetchone()[0] or L["updated"]
            read_at = data.get("relics_at")
            if not isinstance(read_at, (int, float)) or read_at < got + 120000:
                continue   # foto lida antes (ou sem hora): não dá para dizer que sumiu
            if rid not in have:
                self._move(
                    L,
                    "quebrado",
                    "servidor",
                    {"motivo": "relíquia %s sumiu do inventário de quem pegou" % rid},
                )
                self.emit(
                    m["world"],
                    self.admins(m["world"], m["ally_id"]),
                    "emprestimo_quebrado",
                    {"loan_id": L["id"], "relic_id": rid},
                )
                out.append(L["id"])
        return out

    def stock(self, m, full=False):
        self.need(m, "admin", "member")
        light = lambda d: d if full else {k: v for k, v in d.items() if k not in ("effects", "flag_villages")}   # pesados: só com ?full=1
        with self.lock:
            rows = self.q(
                """SELECT s.player_id, s.at, s.data, mb.name FROM snapshots s JOIN members mb ON mb.world=s.world AND mb.player_id=s.player_id
                             WHERE s.world=? AND s.ally_id=? AND mb.role IN ('admin','member')""",
                (m["world"], m["ally_id"]),
            ).fetchall()
            hist = {}
            for x in self.q("SELECT borrower_id, state, late FROM loans WHERE world=? AND ally_id=?", (m["world"], m["ally_id"])):
                h = hist.setdefault(x["borrower_id"], {"devolvidos": 0, "quebrados": 0, "atrasados": 0, "ativos": 0})
                if x["state"] == "devolvido":
                    h["devolvidos"] += 1
                elif x["state"] == "quebrado":
                    h["quebrados"] += 1
                elif x["state"] in ACTIVE:
                    h["ativos"] += 1
                if x["late"]:
                    h["atrasados"] += 1
            return {
                "members": [
                    dict(
                        player_id=r["player_id"],
                        name=r["name"],
                        at=r["at"],
                        online=self.is_online(m["world"], r["player_id"]),
                        hist=hist.get(r["player_id"], {"devolvidos": 0, "quebrados": 0, "atrasados": 0, "ativos": 0}),
                        **light(json.loads(r["data"])),
                    )
                    for r in rows
                ],
                "loans": self.loans(m, active_only=True),
                "server_now": now_ms(),
            }

    # ---------- empréstimos ----------
    def _loan_out(self, L, with_events=False, viewer=None):
        d = dict(L)
        for k in ("item", "collateral", "target"):
            d[k] = json.loads(d[k]) if d[k] else None
        if viewer is None or str(viewer) != str(d["borrower_id"]):
            d["target"] = None   # segurança: a aldeia que recebe só quem pegou vê
        d["late"] = bool(d["late"])
        if with_events:
            d["events"] = [
                dict(e, data=json.loads(e["data"]) if e["data"] else None)
                for e in self.q(
                    "SELECT * FROM loan_events WHERE loan_id=? ORDER BY id", (L["id"],)
                )
            ]
        return d

    def loans(self, m, active_only=False):
        self.need(m, "admin", "member")
        with self.lock:
            sql = (
                "SELECT * FROM loans WHERE world=? AND ally_id=?"
                + (
                    " AND state IN (%s)" % ",".join("?" * len(ACTIVE))
                    if active_only
                    else ""
                )
                + " ORDER BY id DESC LIMIT 500"
            )
            return [
                self._loan_out(L, viewer=m["player_id"])
                for L in self.q(
                    sql, (m["world"], m["ally_id"]) + (ACTIVE if active_only else ())
                )
            ]

    def loan(self, m, lid):
        self.need(m, "admin", "member")
        with self.lock:
            L = self.q(
                "SELECT * FROM loans WHERE id=? AND world=? AND ally_id=?",
                (lid, m["world"], m["ally_id"]),
            ).fetchone()
            if not L:
                raise ApiError(404, "empréstimo não encontrado")
            return self._loan_out(L, True, viewer=m["player_id"])

    def _member_ok(self, m, pid):
        r = self.q(
            "SELECT role FROM members WHERE world=? AND ally_id=? AND player_id=?",
            (m["world"], m["ally_id"], pid),
        ).fetchone()
        return r and r["role"] in ("admin", "member")

    def _item_key(self, kind, item):
        if kind == "relic":
            return "r:%s" % item["relic_id"]
        return None  # bandeiras são contáveis: sem conflito por item

    def _conflict(self, world, kind, item, start, end, skip_id=None):
        key = self._item_key(kind, item)
        if not key:
            return None
        for L in self.q(
            "SELECT * FROM loans WHERE world=? AND kind=? AND state IN (%s)"
            % ",".join("?" * len(ACTIVE)),
            (world, kind) + ACTIVE,
        ):
            if L["id"] == skip_id or self._item_key(kind, json.loads(L["item"])) != key:
                continue
            if start < L["end"] and L["start"] < end:
                return L["id"]
        return None

    def create_loan(self, m, b):
        self.need(m, "admin", "member")
        kind = b.get("kind")
        owner = str(b.get("owner_id") or "")
        item = b.get("item") or {}
        mode = b.get("mode") or "caucao"
        try:
            start, end = int(b.get("start")), int(b.get("end"))
        except (TypeError, ValueError):
            raise ApiError(400, "início e fim (ms) obrigatórios")
        if kind not in ("relic", "flag"):
            raise ApiError(400, "kind = relic ou flag")
        if mode not in ("caucao", "livre"):
            raise ApiError(400, "mode = caucao (com caução) ou livre (sem caução)")
        if owner == m["player_id"]:
            raise ApiError(400, "não dá para pedir a si mesmo")
        if end <= start:
            raise ApiError(400, "o fim precisa ser depois do início")
        if kind == "relic":
            if not str(item.get("relic_id") or "").isdigit():
                raise ApiError(400, "item.relic_id obrigatório")
            item = {"relic_id": int(item["relic_id"])}
        else:
            try:
                item = {
                    "flag_type": int(item["flag_type"]),
                    "level": int(item["level"]),
                    "amount": int(item["amount"]),
                }
            except (KeyError, TypeError, ValueError):
                raise ApiError(400, "item = {flag_type, level, amount}")
            if item["amount"] < 1:
                raise ApiError(400, "quantidade ≥ 1")
        with self.lock:
            if not self._member_ok(m, owner):
                raise ApiError(404, "dono não é membro aprovado desta tribo")
            snap = self.q(
                "SELECT data FROM snapshots WHERE world=? AND player_id=?",
                (m["world"], owner),
            ).fetchone()
            if kind == "relic":
                rel = (
                    [r for r in (json.loads(snap["data"]).get("relics") or [])]
                    if snap
                    else []
                )
                lent_by_owner = any(
                    str(json.loads(x["item"]).get("relic_id")) == str(item["relic_id"])
                    for x in self.q(
                        "SELECT item FROM loans WHERE world=? AND kind='relic' AND owner_id=? AND state IN (%s)" % ",".join("?" * len(ACTIVE)),
                        (m["world"], owner) + ACTIVE,
                    )
                )
                if not lent_by_owner and not any(
                    str(r.get("id")) == str(item["relic_id"])
                    for r in rel
                    if isinstance(r, dict)
                ):
                    raise ApiError(
                        404, "essa relíquia não está no último inventário do dono"
                    )
                if any(str(r.get("id")) == str(item["relic_id"]) and r.get("no_lend") for r in rel if isinstance(r, dict)):
                    raise ApiError(403, "o dono marcou essa relíquia como \"não emprestar\"")
            c = self._conflict(m["world"], kind, item, start, end)
            if c:
                raise ApiError(
                    409, "conflito com o empréstimo/reserva #%d nessa janela" % c
                )
            t = now_ms()
            cur = self.q(
                """INSERT INTO loans (world, ally_id, kind, owner_id, borrower_id, item, mode, collateral, target, start, end, note, state, created, updated)
                            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    m["world"],
                    m["ally_id"],
                    kind,
                    owner,
                    m["player_id"],
                    json.dumps(item),
                    mode,
                    json.dumps(b.get("collateral")) if b.get("collateral") else None,
                    json.dumps(b.get("target")) if b.get("target") else None,
                    start,
                    end,
                    str(b.get("note") or "")[:500],
                    "pedido",
                    t,
                    t,
                ),
            )
            lid = cur.lastrowid
            self.q(
                "INSERT INTO loan_events (loan_id, at, actor, from_state, to_state, data) VALUES (?,?,?,?,?,?)",
                (lid, t, m["player_id"], None, "pedido", None),
            )
            self.emit(m["world"], [owner], "pedido", {"loan_id": lid, "de": m["name"]})
            self.db.commit()
            return self.loan(m, lid)

    def _move(self, L, to, actor, data):
        t = now_ms()
        sets, args = ["state=?", "updated=?"], [to, t]
        if data and data.get("offer_id") is not None:
            sets.append("offer_id=?")
            args.append(str(data["offer_id"]))
        self.q("UPDATE loans SET %s WHERE id=?" % ", ".join(sets), args + [L["id"]])
        self.q(
            "INSERT INTO loan_events (loan_id, at, actor, from_state, to_state, data) VALUES (?,?,?,?,?,?)",
            (
                L["id"],
                t,
                actor,
                L["state"],
                to,
                json.dumps(data, ensure_ascii=False) if data else None,
            ),
        )
        self.emit(
            L["world"],
            [L["owner_id"], L["borrower_id"]],
            "estado",
            {
                "loan_id": L["id"],
                "de": L["state"],
                "para": to,
                "por": actor,
                "dados": data,
            },
        )

    def transition(self, m, lid, b):
        self.need(m, "admin", "member")
        to = b.get("to")
        data = b.get("data") if isinstance(b.get("data"), dict) else {}
        with self.lock:
            L = self.q(
                "SELECT * FROM loans WHERE id=? AND world=? AND ally_id=?",
                (lid, m["world"], m["ally_id"]),
            ).fetchone()
            if not L:
                raise ApiError(404, "empréstimo não encontrado")
            who = TRANSITIONS.get((L["state"], to))
            if not who:
                raise ApiError(409, "transição inválida: %s → %s" % (L["state"], to))
            role = (
                "owner"
                if m["player_id"] == L["owner_id"]
                else "borrower"
                if m["player_id"] == L["borrower_id"]
                else None
            )
            if not role or (who != "both" and who != role):
                raise ApiError(
                    403,
                    "só %s pode fazer %s → %s"
                    % (
                        {
                            "owner": "o dono",
                            "borrower": "quem pegou",
                            "both": "as partes",
                        }[who],
                        L["state"],
                        to,
                    ),
                )
            if to in ("ida_oferta", "volta_oferta") and not data.get("offer_id"):
                raise ApiError(400, "offer_id obrigatório")
            if (
                L["state"] == "pedido"
                and to == "aceito"
                and (data.get("start") or data.get("end"))
            ):
                start, end = (
                    int(data.get("start") or L["start"]),
                    int(data.get("end") or L["end"]),
                )
                if end <= start:
                    raise ApiError(400, "o fim precisa ser depois do início")
                c = self._conflict(
                    L["world"],
                    L["kind"],
                    json.loads(L["item"]),
                    start,
                    end,
                    skip_id=L["id"],
                )
                if c:
                    raise ApiError(
                        409, "conflito com o empréstimo/reserva #%d nessa janela" % c
                    )
                self.q(
                    "UPDATE loans SET start=?, end=? WHERE id=?", (start, end, L["id"])
                )
            if data.get("collateral") and L["state"] in ("pedido", "aceito"):
                self.q(
                    "UPDATE loans SET collateral=? WHERE id=?",
                    (json.dumps(data["collateral"]), L["id"]),
                )
            self._move(L, to, m["player_id"], data)
            self.db.commit()
            return self.loan(m, lid)

    def alert(self, m, lid, b):
        """Aviso de uma parte (atrasado, oferta roubada, etc.): histórico + evento para os dois (e admins se grave)."""
        self.need(m, "admin", "member")
        typ = str(b.get("type") or "")[:40]
        note = str(b.get("note") or "")[:500]
        with self.lock:
            L = self.q(
                "SELECT * FROM loans WHERE id=? AND world=? AND ally_id=?",
                (lid, m["world"], m["ally_id"]),
            ).fetchone()
            if not L or m["player_id"] not in (L["owner_id"], L["borrower_id"]):
                raise ApiError(404, "empréstimo não encontrado")
            if typ == "atrasado":
                self.q("UPDATE loans SET late=1 WHERE id=?", (lid,))
            elif typ == "em_dia":
                self.q("UPDATE loans SET late=0 WHERE id=?", (lid,))
            self.q(
                "INSERT INTO loan_events (loan_id, at, actor, from_state, to_state, data) VALUES (?,?,?,?,?,?)",
                (
                    lid,
                    now_ms(),
                    m["player_id"],
                    L["state"],
                    L["state"],
                    json.dumps({"alerta": typ, "nota": note}, ensure_ascii=False),
                ),
            )
            who = [L["owner_id"], L["borrower_id"]] + (
                self.admins(m["world"], m["ally_id"])
                if typ in ("oferta_roubada", "quebra")
                else []
            )
            self.emit(
                m["world"],
                who,
                "alerta",
                {"loan_id": lid, "tipo": typ, "nota": note, "por": m["name"]},
            )
            self.db.commit()
            return self.loan(m, lid)

    # ---------- admin ----------
    def change_key(self, m, b):
        self.need(m, "admin")
        key = str(b.get("new_key") or "")
        if len(key) < 6:
            raise ApiError(400, "chave da tribo curta (mínimo 6 caracteres)")
        with self.lock:
            self.q("UPDATE tribes SET key_hash=? WHERE world=? AND ally_id=?", (sha(key), m["world"], m["ally_id"]))
            self.db.commit()
        return {"ok": True}

    def issues(self, m):
        """Para o admin: pendentes, empréstimos quebrados ou atrasados, e ativos com o fim já passado há mais de 2 h."""
        self.need(m, "admin")
        t = now_ms()
        with self.lock:
            pend = [dict(r) for r in self.q("SELECT player_id, name, created FROM members WHERE world=? AND ally_id=? AND role='pending'", (m["world"], m["ally_id"]))]
            rows = self.q(
                "SELECT * FROM loans WHERE world=? AND ally_id=? AND (state='quebrado' OR late=1 OR (state IN (%s) AND end < ?)) ORDER BY id DESC LIMIT 100"
                % ",".join("?" * len(ACTIVE)),
                (m["world"], m["ally_id"]) + ACTIVE + (t - 2 * 3600 * 1000,),
            ).fetchall()
            return {"pending": pend, "loans": [self._loan_out(L) for L in rows]}

    def backup(self, folder, keep=14):
        """Cópia consistente do banco (API de backup do SQLite) em folder/tesouraria-AAAAMMDD-HHMMSS.db; guarda as `keep` mais novas."""
        os.makedirs(folder, exist_ok=True)
        dst_path = os.path.join(folder, time.strftime("tesouraria-%Y%m%d-%H%M%S.db"))
        with self.lock:
            dst = sqlite3.connect(dst_path)
            try:
                self.db.backup(dst)
            finally:
                dst.close()
        olds = sorted(f for f in os.listdir(folder) if f.startswith("tesouraria-") and f.endswith(".db"))
        for f in olds[:-keep] if keep > 0 else []:
            try:
                os.remove(os.path.join(folder, f))
            except OSError:
                pass
        return dst_path

    # ---------- eventos ----------
    def events_since(self, m, since):
        return [
            dict(id=r["id"], at=r["at"], type=r["type"], data=json.loads(r["data"]))
            for r in self.q(
                "SELECT * FROM events WHERE world=? AND player_id=? AND id>? ORDER BY id LIMIT 200",
                (m["world"], m["player_id"], since),
            )
        ]

    def wait_events(self, m, since, timeout):
        end = time.time() + timeout
        with self.cond:
            while True:
                ev = self.events_since(m, since)
                left = end - time.time()
                if ev or left <= 0:
                    return ev
                self.cond.wait(min(left, 5))

    def set_online(self, m, delta):
        with self.lock:
            k = (m["world"], m["player_id"])
            self.online[k] = max(0, self.online.get(k, 0) + delta)
            self.last_poll[k] = time.time()

    def is_online(self, world, pid):
        """Com a aba vigia aberta: uma espera de eventos aberta agora, ou a última acabou há menos de 40 s."""
        k = (world, str(pid))
        return self.online.get(k, 0) > 0 or time.time() - self.last_poll.get(k, 0) < 15


def make_handler(store, access_log, allow_origin, trust_proxy=False, rl_user=None, rl_reg=None):
    rl_user = rl_user or RateLimit(600, 60)   # por membro: 600 pedidos/min (uso normal: poucos por minuto; o long-poll faz ~2)
    rl_reg = rl_reg or RateLimit(10, 60)      # cadastro por IP: 10/min (chave da tribo não dá para adivinhar no chute)

    class H(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        server_version = "Tesouraria/1"

        def log_message(self, fmt, *args):
            if access_log:
                with open(access_log, "a", encoding="utf8") as f:
                    f.write(
                        "%s %s %s\n"
                        % (
                            time.strftime("%Y-%m-%d %H:%M:%S"),
                            self.client_address[0],
                            re.sub(r"token=[^&\s]+", "token=***", fmt % args),
                        )
                    )

        def _send(self, status, obj):
            body = json.dumps(obj, ensure_ascii=False).encode("utf8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            if allow_origin:
                self.send_header("Access-Control-Allow-Origin", allow_origin)
            self.end_headers()
            self.wfile.write(body)

        def _body(self):
            n = int(self.headers.get("Content-Length") or 0)
            if n > MAX_BODY:
                raise ApiError(413, "corpo grande demais")
            if not n:
                return {}
            try:
                b = json.loads(self.rfile.read(n).decode("utf8"))
            except ValueError:
                raise ApiError(400, "JSON inválido")
            if not isinstance(b, dict):
                raise ApiError(400, "JSON precisa ser objeto")
            return b

        def _token(self, qs):
            a = self.headers.get("Authorization") or ""
            return (
                a[7:].strip()
                if a.startswith("Bearer ")
                else (qs.get("token") or [""])[0]
            )

        def do_OPTIONS(self):
            self.send_response(204)
            if allow_origin:
                self.send_header("Access-Control-Allow-Origin", allow_origin)
                self.send_header(
                    "Access-Control-Allow-Headers", "Authorization, Content-Type"
                )
                self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT")
            self.send_header("Content-Length", "0")
            self.end_headers()

        def _ip(self):
            if trust_proxy:
                f = (self.headers.get("X-Forwarded-For") or "").split(",")[0].strip()
                if f:
                    return f
            return self.client_address[0]

        def _route(self, method):
            u = urlparse(self.path)
            qs = parse_qs(u.query)
            p = u.path.rstrip("/")
            if method == "GET" and p == "/v1/health":
                return self._send(200, {"ok": True, "server_now": now_ms()})
            if method == "POST" and p == "/v1/register":
                if not rl_reg.ok("reg:" + self._ip()):
                    raise ApiError(429, "muitos cadastros deste endereço: espere 1 minuto")
                return self._send(200, store.register(self._body()))
            tok = self._token(qs)
            if not rl_user.ok("tok:" + sha(tok or self._ip())):
                raise ApiError(429, "muitos pedidos: espere um pouco")
            m = store.auth(tok)
            if method == "POST" and p == "/v1/tribe/key":
                return self._send(200, store.change_key(m, self._body()))
            if method == "GET" and p == "/v1/admin/issues":
                return self._send(200, store.issues(m))
            if method == "GET" and p == "/v1/me":
                return self._send(
                    200,
                    {
                        k: m[k]
                        for k in ("world", "ally_id", "player_id", "name", "role")
                    },
                )
            if method == "GET" and p == "/v1/members":
                return self._send(200, store.members(m))
            r = re.match(r"^/v1/members/(\d+)/(approve|admin|remove)$", p)
            if method == "POST" and r:
                return self._send(200, store.set_role(m, r.group(1), r.group(2)))
            if method == "PUT" and p == "/v1/snapshot":
                return self._send(200, store.put_snapshot(m, self._body()))
            if method == "GET" and p == "/v1/stock":
                return self._send(200, store.stock(m, full=(qs.get("full") or ["0"])[0] == "1"))
            if method == "GET" and p == "/v1/loans":
                return self._send(
                    200,
                    store.loans(m, active_only=(qs.get("active") or ["0"])[0] == "1"),
                )
            if method == "POST" and p == "/v1/loans":
                return self._send(200, store.create_loan(m, self._body()))
            r = re.match(r"^/v1/loans/(\d+)$", p)
            if method == "GET" and r:
                return self._send(200, store.loan(m, int(r.group(1))))
            r = re.match(r"^/v1/loans/(\d+)/(move|alert)$", p)
            if method == "POST" and r:
                fn = store.transition if r.group(2) == "move" else store.alert
                return self._send(200, fn(m, int(r.group(1)), self._body()))
            if method == "GET" and p == "/v1/events":
                since = int((qs.get("since") or ["0"])[0] or 0)
                if "text/event-stream" in (self.headers.get("Accept") or ""):
                    return self._sse(m, since)
                wait = min(30, max(0, int((qs.get("wait") or ["0"])[0] or 0)))
                store.set_online(m, 1)
                try:
                    ev = (
                        store.wait_events(m, since, wait)
                        if wait
                        else store.events_since(m, since)
                    )
                finally:
                    store.set_online(m, -1)
                return self._send(200, {"events": ev, "server_now": now_ms()})
            raise ApiError(404, "rota desconhecida")

        def _sse(self, m, since):
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close")
            self.end_headers()
            self.close_connection = True
            store.set_online(m, 1)
            try:
                self.wfile.write(b": ok\n\n")
                self.wfile.flush()
                while True:
                    ev = store.wait_events(m, since, 25)
                    for e in ev:
                        since = e["id"]
                        self.wfile.write(
                            (
                                "id: %d\nevent: %s\ndata: %s\n\n"
                                % (
                                    e["id"],
                                    e["type"],
                                    json.dumps(e, ensure_ascii=False),
                                )
                            ).encode("utf8")
                        )
                    if not ev:
                        self.wfile.write(b": ping\n\n")
                    self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, OSError):
                pass
            finally:
                store.set_online(m, -1)

        def _handle(self, method):
            try:
                self._route(method)
            except ApiError as e:
                self._send(e.status, {"error": e.msg})
            except Exception as e:  # nunca derruba o servidor
                self.log_message("ERRO %r", e)
                self._send(500, {"error": "erro interno"})

        def do_GET(self):
            self._handle("GET")

        def do_POST(self):
            self._handle("POST")

        def do_PUT(self):
            self._handle("PUT")

    return H


def make_server(host="127.0.0.1", port=8787, db=None, access_log=None, allow_origin="", trust_proxy=False, backup_dir=None, backup_hours=6, rl_user=None, rl_reg=None):
    store = Store(db or os.path.join(HERE, "tesouraria.db"))
    srv = ThreadingHTTPServer(
        (host, port), make_handler(store, access_log, allow_origin, trust_proxy, rl_user, rl_reg)
    )
    srv.daemon_threads = True
    srv.store = store
    if backup_dir and backup_hours > 0:   # cópia do banco a cada N horas (e uma ao subir)
        def loop():
            while True:
                try:
                    store.backup(backup_dir)
                except Exception as e:   # backup nunca derruba o servidor
                    print("backup falhou:", e)
                time.sleep(backup_hours * 3600)
        threading.Thread(target=loop, daemon=True).start()
    return srv


if __name__ == "__main__":
    host, port = (
        os.environ.get("HOST", "127.0.0.1"),
        int(os.environ.get("PORT", "8787")),
    )
    srv = make_server(
        host,
        port,
        os.environ.get("DB"),
        os.environ.get("ACCESS_LOG", os.path.join(HERE, "access.log")),
        os.environ.get("ALLOW_ORIGIN", ""),
        os.environ.get("TRUST_PROXY", "") == "1",
        os.environ.get("BACKUP_DIR", os.path.join(HERE, "backups")),
        float(os.environ.get("BACKUP_HOURS", "6")),
    )
    print("Tesouraria em http://%s:%d (Ctrl+C para parar)" % (host, port))
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
