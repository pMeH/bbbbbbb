"""Testes do servidor da Tesouraria: python3 -m unittest -v test_server (nesta pasta)."""

import json
import os
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request

from server import make_server

H = 3600 * 1000


class Api:
    def __init__(self, base):
        self.base = base

    def call(self, method, path, body=None, token=None, headers=None):
        data = json.dumps(body).encode("utf8") if body is not None else None
        h = {"Content-Type": "application/json"}
        if token:
            h["Authorization"] = "Bearer " + token
        h.update(headers or {})
        req = urllib.request.Request(
            self.base + path, data=data, method=method, headers=h
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as r:
                return r.status, json.loads(r.read().decode("utf8"))
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read().decode("utf8"))


def relic(i, vid=None):
    return {
        "id": i,
        "name": "Relíquia %d" % i,
        "type": "axe",
        "quality": "refined",
        "village_id": vid,
    }


class TesourariaTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.srv = make_server("127.0.0.1", 0, os.path.join(self.tmp, "t.db"))
        self.t = threading.Thread(target=self.srv.serve_forever, daemon=True)
        self.t.start()
        self.api = Api("http://127.0.0.1:%d" % self.srv.server_address[1])

    def tearDown(self):
        self.srv.shutdown()
        self.srv.server_close()

    def reg(self, pid, ally="355", key="chave-secreta", world="br144", name=None):
        return self.api.call(
            "POST",
            "/v1/register",
            {
                "world": world,
                "ally_id": ally,
                "player_id": pid,
                "player_name": name or "p" + pid,
                "tribe_key": key,
            },
        )

    def tribe(self):
        """admin (1), membro aprovado (2), membro aprovado (3); fotos com relíquias."""
        a = self.reg("1")[1]["token"]
        b = self.reg("2")[1]["token"]
        c = self.reg("3")[1]["token"]
        for pid in ("2", "3"):
            self.assertEqual(
                self.api.call("POST", "/v1/members/%s/approve" % pid, {}, a)[0], 200
            )
        self.api.call(
            "PUT",
            "/v1/snapshot",
            {"ally_id": "355", "relics": [relic(100, 5), relic(101)]},
            a,
        )
        self.api.call(
            "PUT", "/v1/snapshot", {"ally_id": "355", "relics": [relic(200)]}, b
        )
        self.api.call(
            "PUT", "/v1/snapshot", {"ally_id": "355", "relics": [relic(300)]}, c
        )
        return a, b, c

    def test_cadastro_e_aprovacao(self):
        s, r = self.reg("1")
        self.assertEqual((s, r["role"]), (200, "admin"))
        self.assertEqual(self.reg("2", key="errada!!")[0], 403)
        s, r = self.reg("2")
        self.assertEqual(r["role"], "pending")
        tok2 = r["token"]
        self.assertEqual(
            self.api.call(
                "PUT", "/v1/snapshot", {"ally_id": "355", "relics": []}, tok2
            )[0],
            403,
        )
        self.assertEqual(self.api.call("GET", "/v1/stock", token=tok2)[0], 403)
        self.assertEqual(
            self.api.call("POST", "/v1/members/1/approve", {}, tok2)[0], 403
        )  # pendente não aprova ninguém
        self.assertEqual(self.reg("5", ally="0")[0], 400)  # sem tribo
        self.assertEqual(self.api.call("GET", "/v1/me", token="xxx")[0], 401)

    def test_novo_token_mantem_papel(self):
        a = self.reg("1")[1]["token"]
        self.reg("2")
        self.api.call("POST", "/v1/members/2/approve", {}, a)
        s, r = self.reg("2")  # navegador novo: novo token, continua aprovado
        self.assertEqual(r["role"], "member")
        self.assertEqual(
            self.api.call("GET", "/v1/me", token=r["token"])[1]["role"], "member"
        )

    def test_estoque_so_da_tribo(self):
        a, b, c = self.tribe()
        x = self.reg("9", ally="777", key="outra-chave")[1][
            "token"
        ]  # outra tribo, outro admin
        self.api.call(
            "PUT", "/v1/snapshot", {"ally_id": "777", "relics": [relic(900)]}, x
        )
        s, st = self.api.call("GET", "/v1/stock", token=b)
        self.assertEqual(s, 200)
        self.assertEqual(sorted(m["player_id"] for m in st["members"]), ["1", "2", "3"])
        self.assertNotIn("900", json.dumps(st))
        s, st = self.api.call("GET", "/v1/stock", token=x)
        self.assertEqual([m["player_id"] for m in st["members"]], ["9"])

    def test_saiu_da_tribo(self):
        a, b, c = self.tribe()
        s, r = self.api.call("PUT", "/v1/snapshot", {"ally_id": "999", "relics": []}, b)
        self.assertEqual(s, 409)
        st = self.api.call("GET", "/v1/stock", token=a)[1]
        self.assertNotIn("2", [m["player_id"] for m in st["members"]])

    def test_emprestimo_completo_e_permissoes(self):
        a, b, c = self.tribe()
        t0 = int(time.time() * 1000) + H
        s, L = self.api.call(
            "POST",
            "/v1/loans",
            {
                "kind": "relic",
                "owner_id": "1",
                "item": {"relic_id": 100},
                "mode": "caucao",
                "collateral": {"relic_id": 200},
                "target": {"id": 7, "x": 500, "y": 500},
                "start": t0,
                "end": t0 + 30 * H,
            },
            b,
        )
        self.assertEqual((s, L["state"]), (200, "pedido"), L)
        lid = L["id"]
        mv = lambda tok, to, data=None: self.api.call(
            "POST", "/v1/loans/%d/move" % lid, {"to": to, "data": data or {}}, tok
        )
        self.assertEqual(mv(b, "aceito")[0], 403)  # quem pediu não aceita
        self.assertEqual(mv(c, "aceito")[0], 403)  # terceiro não mexe
        self.assertEqual(mv(a, "em_uso")[0], 409)  # pulo inválido
        self.assertEqual(mv(a, "aceito")[0], 200)
        self.assertEqual(mv(a, "preparo")[0], 200)
        self.assertEqual(mv(a, "ida_oferta")[0], 400)  # sem offer_id
        self.assertEqual(
            mv(a, "ida_oferta", {"offer_id": "1777"})[1]["offer_id"], "1777"
        )
        self.assertEqual(mv(a, "ida_ok")[0], 403)  # só quem pegou confirma que aceitou
        self.assertEqual(mv(b, "ida_ok")[0], 200)
        # quem pegou agora tem a relíquia 100 (foto nova); não é quebra
        self.assertEqual(
            self.api.call(
                "PUT", "/v1/snapshot", {"ally_id": "355", "relics": [relic(100, 7)]}, b
            )[1]["quebrados"],
            [],
        )
        self.assertEqual(mv(b, "em_uso")[0], 200)
        self.assertEqual(mv(b, "volta_oferta", {"offer_id": "1800"})[0], 200)
        s, L = mv(a, "devolvido")
        self.assertEqual(L["state"], "devolvido")
        hist = [
            e["to_state"]
            for e in self.api.call("GET", "/v1/loans/%d" % lid, token=c)[1]["events"]
        ]  # a tribo inteira vê o histórico
        self.assertEqual(
            hist,
            [
                "pedido",
                "aceito",
                "preparo",
                "ida_oferta",
                "ida_ok",
                "em_uso",
                "volta_oferta",
                "devolvido",
            ],
        )

    def test_validacoes_do_pedido(self):
        a, b, c = self.tribe()
        t0 = int(time.time() * 1000) + H
        base = {
            "kind": "relic",
            "owner_id": "1",
            "item": {"relic_id": 100},
            "start": t0,
            "end": t0 + 30 * H,
        }
        self.assertEqual(
            self.api.call("POST", "/v1/loans", dict(base, owner_id="2"), b)[0], 400
        )  # a si mesmo
        self.assertEqual(
            self.api.call("POST", "/v1/loans", dict(base, item={"relic_id": 555}), b)[
                0
            ],
            404,
        )  # não está no inventário
        self.assertEqual(
            self.api.call("POST", "/v1/loans", dict(base, end=t0 - 1), b)[0], 400
        )
        self.assertEqual(
            self.api.call("POST", "/v1/loans", dict(base, mode="x"), b)[0], 400
        )
        self.assertEqual(
            self.api.call("POST", "/v1/loans", dict(base, owner_id="77"), b)[0], 404
        )
        s, f = self.api.call(
            "POST",
            "/v1/loans",
            {
                "kind": "flag",
                "owner_id": "1",
                "item": {"flag_type": 4, "level": 2, "amount": 3},
                "mode": "livre",
                "start": t0,
                "end": t0 + H,
            },
            b,
        )
        self.assertEqual(
            (s, f["item"]), (200, {"flag_type": 4, "level": 2, "amount": 3})
        )

    def test_conflito_de_reserva(self):
        a, b, c = self.tribe()
        t0 = int(time.time() * 1000) + H
        p = lambda tok, s, e: self.api.call(
            "POST",
            "/v1/loans",
            {
                "kind": "relic",
                "owner_id": "1",
                "item": {"relic_id": 100},
                "start": s,
                "end": e,
            },
            tok,
        )
        self.assertEqual(p(b, t0, t0 + 30 * H)[0], 200)
        s, r = p(c, t0 + 10 * H, t0 + 40 * H)
        self.assertEqual(s, 409, r)
        self.assertEqual(p(c, t0 + 30 * H, t0 + 60 * H)[0], 200)  # encosta, não cruza
        # recusado libera a janela
        lid = self.api.call("GET", "/v1/loans?active=1", token=a)[1][-1]["id"]
        self.assertEqual(
            self.api.call("POST", "/v1/loans/%d/move" % lid, {"to": "recusado"}, a)[0],
            200,
        )
        self.assertEqual(p(c, t0 + 10 * H, t0 + 20 * H)[0], 200)
        # dono muda a janela ao aceitar: conflito também vale
        lid2 = self.api.call("GET", "/v1/loans?active=1", token=a)[1][0]["id"]
        s, r = self.api.call(
            "POST",
            "/v1/loans/%d/move" % lid2,
            {"to": "aceito", "data": {"start": t0 + 25 * H, "end": t0 + 35 * H}},
            a,
        )
        self.assertEqual(s, 409, r)

    def test_quebra(self):
        a, b, c = self.tribe()
        t0 = int(time.time() * 1000) + H
        lid = self.api.call(
            "POST",
            "/v1/loans",
            {
                "kind": "relic",
                "owner_id": "1",
                "item": {"relic_id": 100},
                "start": t0,
                "end": t0 + 30 * H,
            },
            b,
        )[1]["id"]
        mv = lambda tok, to, data=None: self.api.call(
            "POST", "/v1/loans/%d/move" % lid, {"to": to, "data": data or {}}, tok
        )
        mv(a, "aceito")
        mv(a, "ida_oferta", {"offer_id": "1"})
        mv(b, "ida_ok")
        now = int(time.time() * 1000)
        s, r = self.api.call(
            "PUT", "/v1/snapshot", {"ally_id": "355", "relics": [relic(200)], "relics_at": now - 60000}, b
        )  # foto lida ANTES de receber: não é quebra
        self.assertEqual(r["quebrados"], [])
        s, r = self.api.call(
            "PUT", "/v1/snapshot", {"ally_id": "355", "relics": [relic(200)]}, b
        )  # sem hora de leitura: não dá para dizer
        self.assertEqual(r["quebrados"], [])
        s, r = self.api.call(
            "PUT", "/v1/snapshot", {"ally_id": "355", "relics": [relic(200)], "relics_at": now + 3 * 60000}, b
        )  # lida depois e a 100 sumiu
        self.assertEqual(r["quebrados"], [lid])
        self.assertEqual(
            self.api.call("GET", "/v1/loans/%d" % lid, token=a)[1]["state"], "quebrado"
        )
        ev = self.api.call("GET", "/v1/events?since=0", token=a)[1]["events"]
        self.assertIn("emprestimo_quebrado", [e["type"] for e in ev])  # admin avisado

    def test_alerta(self):
        a, b, c = self.tribe()
        t0 = int(time.time() * 1000) + H
        lid = self.api.call(
            "POST",
            "/v1/loans",
            {
                "kind": "relic",
                "owner_id": "1",
                "item": {"relic_id": 100},
                "start": t0,
                "end": t0 + 30 * H,
            },
            b,
        )[1]["id"]
        s, L = self.api.call(
            "POST",
            "/v1/loans/%d/alert" % lid,
            {"type": "atrasado", "note": "lealdade 80"},
            b,
        )
        self.assertTrue(L["late"])
        self.assertEqual(
            self.api.call("POST", "/v1/loans/%d/alert" % lid, {"type": "atrasado"}, c)[
                0
            ],
            404,
        )  # terceiro não

    def test_eventos_long_poll_e_online(self):
        a, b, c = self.tribe()
        last = max(
            [
                e["id"]
                for e in self.api.call("GET", "/v1/events?since=0", token=a)[1][
                    "events"
                ]
            ]
            or [0]
        )
        out = {}

        def waiter():
            out["r"] = self.api.call(
                "GET", "/v1/events?since=%d&wait=10" % last, token=a
            )

        th = threading.Thread(target=waiter)
        th.start()
        time.sleep(0.3)
        self.assertTrue(
            [
                m
                for m in self.api.call("GET", "/v1/members", token=b)[1]
                if m["player_id"] == "1"
            ][0]["online"]
        )
        t0 = int(time.time() * 1000) + H
        tic = time.time()
        self.api.call(
            "POST",
            "/v1/loans",
            {
                "kind": "relic",
                "owner_id": "1",
                "item": {"relic_id": 100},
                "start": t0,
                "end": t0 + 30 * H,
            },
            b,
        )
        th.join(5)
        self.assertLess(time.time() - tic, 3, "o long-poll acorda na hora")
        self.assertEqual([e["type"] for e in out["r"][1]["events"]], ["pedido"])
        on = lambda: [m for m in self.api.call("GET", "/v1/members", token=b)[1] if m["player_id"] == "1"][0]["online"]
        self.assertTrue(on(), "entre um long-poll e outro continua online (folga de 15 s)")
        self.srv.store.last_poll[("br144", "1")] = time.time() - 60
        self.assertFalse(on(), "sem esperar eventos há 1 min: offline")

    def test_sse(self):
        a, b, c = self.tribe()
        req = urllib.request.Request(
            self.api.base + "/v1/events?since=0",
            headers={"Authorization": "Bearer " + a, "Accept": "text/event-stream"},
        )
        r = urllib.request.urlopen(req, timeout=10)
        self.assertEqual(r.readline(), b": ok\n")
        r.readline()
        t0 = int(time.time() * 1000) + H
        self.api.call(
            "POST",
            "/v1/loans",
            {
                "kind": "relic",
                "owner_id": "1",
                "item": {"relic_id": 100},
                "start": t0,
                "end": t0 + 30 * H,
            },
            b,
        )
        lines = []
        while not any(l.startswith(b"event: pedido") for l in lines):
            lines.append(r.readline())
        r.close()

    def test_admin_remove(self):
        a, b, c = self.tribe()
        self.assertEqual(
            self.api.call("POST", "/v1/members/1/remove", {}, a)[0], 409
        )  # único admin
        self.assertEqual(self.api.call("POST", "/v1/members/3/remove", {}, a)[0], 200)
        self.assertEqual(self.api.call("GET", "/v1/stock", token=c)[0], 403)
        self.assertNotIn(
            "3",
            [
                m["player_id"]
                for m in self.api.call("GET", "/v1/stock", token=a)[1]["members"]
            ],
        )


if __name__ == "__main__":
    unittest.main()


class EndurecimentoTest(unittest.TestCase):
    """P8: limite de pedidos, troca da chave, problemas para o admin, backup."""

    def setUp(self):
        from server import RateLimit
        self.tmp = tempfile.mkdtemp()
        self.srv = make_server("127.0.0.1", 0, os.path.join(self.tmp, "t.db"), rl_user=RateLimit(20, 60), rl_reg=RateLimit(7, 60))
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.api = Api("http://127.0.0.1:%d" % self.srv.server_address[1])

    def tearDown(self):
        self.srv.shutdown()
        self.srv.server_close()

    def reg(self, pid, key="chave-secreta"):
        return self.api.call("POST", "/v1/register", {"world": "br144", "ally_id": "355", "player_id": pid, "player_name": "p" + pid, "tribe_key": key})

    def test_limites(self):
        a = self.reg("1")[1]["token"]
        codes = [self.api.call("GET", "/v1/me", token=a)[0] for _ in range(25)]
        self.assertIn(429, codes)
        self.assertEqual(codes[:19], [200] * 19)
        codes = [self.reg(str(10 + i), key="errada!!")[0] for i in range(8)]
        self.assertEqual(codes[-1], 429)   # chutar a chave: barrado

    def test_trocar_chave_e_problemas(self):
        a = self.reg("1")[1]["token"]
        self.reg("2")
        b = self.reg("3")[1]["token"]
        self.assertEqual(self.api.call("POST", "/v1/tribe/key", {"new_key": "x"}, a)[0], 400)
        self.assertEqual(self.api.call("POST", "/v1/tribe/key", {"new_key": "nova-chave"}, b)[0], 403)   # pendente não
        self.assertEqual(self.api.call("POST", "/v1/tribe/key", {"new_key": "nova-chave"}, a)[0], 200)
        self.assertEqual(self.reg("4")[0], 403)                       # a velha não vale mais
        self.assertEqual(self.reg("4", key="nova-chave")[0], 200)
        self.assertEqual(self.api.call("GET", "/v1/me", token=a)[0], 200)   # tokens antigos continuam
        s, r = self.api.call("GET", "/v1/admin/issues", token=a)
        self.assertEqual(sorted(x["player_id"] for x in r["pending"]), ["2", "3", "4"])
        self.api.call("POST", "/v1/members/2/approve", {}, a)
        t2 = self.reg("2", key="nova-chave")[1]["token"]
        self.api.call("PUT", "/v1/snapshot", {"ally_id": "355", "relics": [relic(100)]}, a)
        t0 = int(time.time() * 1000) - 10 * H   # janela que já acabou
        lid = self.api.call("POST", "/v1/loans", {"kind": "relic", "owner_id": "1", "item": {"relic_id": 100}, "start": t0, "end": t0 + 5 * H}, t2)[1]["id"]
        self.api.call("POST", "/v1/loans/%d/move" % lid, {"to": "aceito"}, a)
        r = self.api.call("GET", "/v1/admin/issues", token=a)[1]
        self.assertEqual([x["id"] for x in r["loans"]], [lid])   # ativo com o fim passado
        self.assertEqual(self.api.call("GET", "/v1/admin/issues", token=t2)[0], 403)

    def test_backup(self):
        a = self.reg("1")[1]["token"]
        folder = os.path.join(self.tmp, "bk")
        for _ in range(3):
            self.srv.store.backup(folder, keep=2)
            time.sleep(1.1)
        fs = sorted(os.listdir(folder))
        self.assertEqual(len(fs), 2)
        import sqlite3
        c = sqlite3.connect(os.path.join(folder, fs[-1]))
        self.assertEqual(c.execute("SELECT COUNT(*) FROM members").fetchone()[0], 1)
        c.close()
        self.assertTrue(a)


class PedidoDeEmprestadaTest(TesourariaTest):
    """A relíquia está com quem pegou: o próximo pede ao DONO (que não a tem na foto), para depois da devolução."""

    def test_pedir_ao_dono_a_emprestada(self):
        a, b, c = self.tribe()
        t0 = int(time.time() * 1000) + H
        lid = self.api.call("POST", "/v1/loans", {"kind": "relic", "owner_id": "1", "item": {"relic_id": 100}, "start": t0, "end": t0 + 30 * H}, b)[1]["id"]
        mv = lambda tok, to, data=None: self.api.call("POST", "/v1/loans/%d/move" % lid, {"to": to, "data": data or {}}, tok)
        mv(a, "aceito"); mv(a, "ida_oferta", {"offer_id": "1"}); mv(b, "ida_ok")
        self.api.call("PUT", "/v1/snapshot", {"ally_id": "355", "relics": [relic(101)]}, a)   # a 100 saiu da foto do dono
        s, r = self.api.call("POST", "/v1/loans", {"kind": "relic", "owner_id": "1", "item": {"relic_id": 100}, "start": t0 + 31 * H, "end": t0 + 60 * H}, c)
        self.assertEqual(s, 200, r)
        s, r = self.api.call("POST", "/v1/loans", {"kind": "relic", "owner_id": "2", "item": {"relic_id": 100}, "start": t0 + 70 * H, "end": t0 + 80 * H}, c)
        self.assertEqual(s, 404, "a quem só está com ela emprestada, não")


class FotoParcialTest(TesourariaTest):
    def test_junta_partes_e_estoque_leve(self):
        a, b, c = self.tribe()
        self.api.call("PUT", "/v1/snapshot", {"ally_id": "355", "relics": [relic(100)], "effects": {"5": {"lines": [{"line": "x"}]}}, "flag_villages": {"5": {"txt": "4%"}}}, a)
        self.api.call("PUT", "/v1/snapshot", {"ally_id": "355", "relics": [relic(100), relic(102)], "flags": {"4": {"2": 3}}}, a)   # sem effects: continua
        me = [m for m in self.api.call("GET", "/v1/stock?full=1", token=a)[1]["members"] if m["player_id"] == "1"][0]
        self.assertEqual((len(me["relics"]), me["flags"], me["effects"], me["flag_villages"]), (2, {"4": {"2": 3}}, None, None))   # efeitos/bandeira por aldeia: nunca guardados
        light = [m for m in self.api.call("GET", "/v1/stock", token=a)[1]["members"] if m["player_id"] == "1"][0]
        self.assertNotIn("effects", light)
        self.assertNotIn("flag_villages", light)


class SegurancaTest(TesourariaTest):
    """Golpe em tribo: o servidor não sabe onde estão as relíquias; destino só para quem pegou; "não emprestar"; histórico; saiu da tribo avisa."""

    def test_sem_localizacao_e_destino_so_de_quem_pegou(self):
        a, b, c = self.tribe()
        self.api.call("PUT", "/v1/snapshot", {"ally_id": "355", "relics": [relic(100, 77)], "villages": {"77": {"x": 1, "y": 2}}, "effects": {"77": {}}}, a)
        me = [m for m in self.api.call("GET", "/v1/stock?full=1", token=b)[1]["members"] if m["player_id"] == "1"][0]
        self.assertNotIn("village_id", me["relics"][0])
        self.assertTrue(me["relics"][0]["equipped"])
        self.assertIsNone(me["villages"])
        t0 = int(time.time() * 1000) + H
        lid = self.api.call("POST", "/v1/loans", {"kind": "relic", "owner_id": "1", "item": {"relic_id": 100}, "target": {"id": 9, "x": 5, "y": 6, "name": "Frente"}, "start": t0, "end": t0 + 30 * H}, b)[1]["id"]
        self.assertEqual(self.api.call("GET", "/v1/loans/%d" % lid, token=b)[1]["target"]["x"], 5)   # quem pegou vê
        self.assertIsNone(self.api.call("GET", "/v1/loans/%d" % lid, token=a)[1]["target"])         # o dono não
        self.assertIsNone([l for l in self.api.call("GET", "/v1/stock", token=c)[1]["loans"] if l["id"] == lid][0]["target"])

    def test_nao_emprestar_e_historico(self):
        a, b, c = self.tribe()
        self.api.call("PUT", "/v1/snapshot", {"ally_id": "355", "relics": [dict(relic(100), no_lend=True), relic(101)]}, a)
        t0 = int(time.time() * 1000) + H
        s, r = self.api.call("POST", "/v1/loans", {"kind": "relic", "owner_id": "1", "item": {"relic_id": 100}, "start": t0, "end": t0 + H}, b)
        self.assertEqual(s, 403, r)
        lid = self.api.call("POST", "/v1/loans", {"kind": "relic", "owner_id": "1", "item": {"relic_id": 101}, "start": t0, "end": t0 + H}, b)[1]["id"]
        self.api.call("POST", "/v1/loans/%d/alert" % lid, {"type": "atrasado"}, a)
        h = [m for m in self.api.call("GET", "/v1/stock", token=a)[1]["members"] if m["player_id"] == "2"][0]["hist"]
        self.assertEqual(h, {"devolvidos": 0, "quebrados": 0, "atrasados": 1, "ativos": 1})

    def test_saiu_da_tribo_avisa_o_dono(self):
        a, b, c = self.tribe()
        t0 = int(time.time() * 1000) + H
        lid = self.api.call("POST", "/v1/loans", {"kind": "relic", "owner_id": "3", "item": {"relic_id": 300}, "start": t0, "end": t0 + H}, b)[1]["id"]
        self.api.call("PUT", "/v1/snapshot", {"ally_id": "999", "relics": []}, b)   # b saiu da tribo
        ev = self.api.call("GET", "/v1/events?since=0", token=c)[1]["events"]
        self.assertTrue(any(e["type"] == "membro_saiu" and e["data"]["emprestimos"] == [lid] for e in ev))
